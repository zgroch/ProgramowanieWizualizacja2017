library(testthat)
library(IFSbmp)

test_check("IFSbmp")
