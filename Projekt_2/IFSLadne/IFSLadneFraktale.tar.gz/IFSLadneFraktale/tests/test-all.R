library("testthat")
library("IFSLadneFraktale")
library("stats")
test_check("IFSLadneFraktale")
